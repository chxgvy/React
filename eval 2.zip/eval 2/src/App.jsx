import React, { useState } from 'react';
import './App.css';
import SignInUser from './components/signinUser.jsx';
import SignUpUser from './components/signupUser.jsx';

import SignUpAdminUser from './components/signupAdminUser.jsx';
import Home from './pages/home.jsx';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
  };

  return (
    <div>
      {!isLoggedIn ? (
        <>
        <div class="signup-flex">
            <SignUpAdminUser/>
            <SignUpUser/>
          </div>
          <div class="signin-flex">
            <SignInUser onSignIn={() => setIsLoggedIn(true)}/>
          </div>
        </>
      ) : (
        <Home onLogout={handleLogout}/>
      )}
    </div>
  );
};

export default App;