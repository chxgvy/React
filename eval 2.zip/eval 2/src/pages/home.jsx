import React from 'react';
import '../styles/home.css';

const Home = ({ onLogout }) => {
    return (
        <div>
            <nav className="nav-bar">
                <ul>
                    <li><a href="#home">Accueil</a></li>
                    <li><a href="#">Conférences</a></li>
                    <li><a href="#">Utilisateurs</a></li>
                    <li><a href="#"><button onClick={onLogout}>Se déconnecter</button></a></li>
                </ul>
            </nav>
            <div id="home">

            </div>
        </div>
    );
};

export default Home;