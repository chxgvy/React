import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import '../styles/nav.css';

const NavigationBar = ({ onLogout, isAdmin }) => {
    return (
        <nav className="nav-bar">
            <ul>
                <li><Link to="/home">Accueil</Link></li>
                {}
                {isAdmin && <li><Link to="/confs">Les conférences</Link></li>}
                {}
                {isAdmin && <li><Link to="/users"> Les utilisateurs</Link></li>}
                <li><button onClick={onLogout}>Se deconnecter</button></li>
            </ul>
        </nav>
    );
};

NavigationBar.propTypes = {
    onLogout: PropTypes.func.isRequired,
    isAdmin: PropTypes.bool.isRequired, // Ajoutez la prop `isAdmin`
};

export default NavigationBar;
