import React, { useState } from 'react';
import axios from 'axios';
import '../styles/auth.css';

const SIGNUP_ADMIN_API_URL = 'http://localhost:4555/signupadmin';
const SignUpAdminUser = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const handleSignUp = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post(SIGNUP_ADMIN_API_URL, {
                id: username,
                password: password,
            });
            const responseData = response.data;
            console.log('Reponse data:', responseData);

            if (responseData) {
                setSuccess("Utilisateur Admin inscrit, connectez-vous.");
                setError(null);
                console.log(`Inscription OK. Response: ${JSON.stringify(responseData)}`);
            } else {
                setError("Réponse incorrecte.");
                setSuccess(null);
            }
        } catch (error) {
            setError(error.response ? error.response.data.error : 'Erreur');
            setSuccess(null);
        }
    };

    return (
        <div className="signup-form">
            <form onSubmit={handleSignUp}>
                <h2>Inscription Admin</h2>
                <div className="form-field">
                    <label>Identifiant :
                    <input type="text" className="form-input" value={username} onChange={(event) => setUsername(event.target.value)} />
                    </label>
                </div>
                <div className="form-field">
                    <label>Mot de passe :
                    <input type="password" className="form-input" value={password} onChange={(event) => setPassword(event.target.value)} />
                    </label>
                </div>
                <button type="submit" className="btn-submit">S'inscrire (Admin)</button>
                {error && <div className="error-message">{error}</div>}
                {success && <div className="success-message">{success}</div>}
            </form>
        </div>
    );
};

export default SignUpAdminUser;